use Mix.Config
config :mg_logger, elasticsearch_url: "http://127.0.0.1:9200"