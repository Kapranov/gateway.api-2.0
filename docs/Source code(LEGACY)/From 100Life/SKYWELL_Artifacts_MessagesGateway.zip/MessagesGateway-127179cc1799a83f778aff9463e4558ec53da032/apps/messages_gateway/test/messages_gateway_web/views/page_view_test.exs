defmodule MessagesGatewayWeb.PageViewTest do
  use MessagesGatewayWeb.ConnCase, async: false
end
