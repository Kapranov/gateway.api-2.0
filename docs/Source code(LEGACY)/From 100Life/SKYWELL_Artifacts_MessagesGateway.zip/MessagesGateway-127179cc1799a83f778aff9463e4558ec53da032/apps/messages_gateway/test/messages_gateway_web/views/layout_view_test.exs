defmodule MessagesGatewayWeb.LayoutViewTest do
  use MessagesGatewayWeb.ConnCase, async: false
end
