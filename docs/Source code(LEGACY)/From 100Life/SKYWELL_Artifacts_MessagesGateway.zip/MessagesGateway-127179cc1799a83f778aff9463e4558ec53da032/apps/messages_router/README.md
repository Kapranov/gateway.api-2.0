# MessagesRouter

**TODO: Add description**

## Installation

If [available in Hex](https://hex.pm/docs/publish), the package can be installed
by adding `messages_router` to your list of dependencies in `mix.exs`:

```elixir
def deps do
  [
    {:messages_router, "~> 0.1.0"}
  ]
end
```

Documentation can be generated with [ExDoc](https://github.com/elixir-lang/ex_doc)
and published on [HexDocs](https://hexdocs.pm). Once published, the docs can
be found at [https://hexdocs.pm/messages_router](https://hexdocs.pm/messages_router).

