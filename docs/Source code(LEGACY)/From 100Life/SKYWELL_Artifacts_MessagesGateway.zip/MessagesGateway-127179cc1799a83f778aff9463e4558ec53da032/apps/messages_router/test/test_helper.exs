Code.require_file "test_redis.exs", __DIR__
ExUnit.start
TestRedis.start