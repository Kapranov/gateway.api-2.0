defmodule SmtpProtocol.Mailer do
  use Bamboo.Mailer, otp_app: :smtp_protocol
end