defmodule TestMailer do
  def deliver_now(_), do: :ok
end
