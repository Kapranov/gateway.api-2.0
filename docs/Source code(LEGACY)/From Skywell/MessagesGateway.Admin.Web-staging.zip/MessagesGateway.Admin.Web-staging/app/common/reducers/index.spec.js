import Reducer, { isAuthorized } from './index';

it('Reducer should be exist', () => {
  expect(Reducer).not.toBeNull();
});
