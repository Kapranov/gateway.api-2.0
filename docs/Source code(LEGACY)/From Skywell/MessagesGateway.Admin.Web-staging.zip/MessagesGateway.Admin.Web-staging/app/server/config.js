export const CLIENT_SECRET = process.env.CLIENT_SECRET || '865df2716a61cf0082b18992827f7cdf';
