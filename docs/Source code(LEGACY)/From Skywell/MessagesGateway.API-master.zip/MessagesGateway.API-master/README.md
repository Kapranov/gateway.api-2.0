# MessagesGateway

**Application for sending messages to users**
